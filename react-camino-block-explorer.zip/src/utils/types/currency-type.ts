export interface Amount {
  value: number;
  currency: string;
  currencyIcon: string;
}
