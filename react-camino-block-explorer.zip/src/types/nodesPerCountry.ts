type NodesPerCountry = {
  country: string;
  alpha2: string;
  nodes: string[];
};

export default NodesPerCountry;
