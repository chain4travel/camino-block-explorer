export interface NodeValidatorsResponse {
  numberOfActiveValidators: number;
  numberOfValidators: number;
}

export interface NodeValidator {
  connected: boolean;
}
