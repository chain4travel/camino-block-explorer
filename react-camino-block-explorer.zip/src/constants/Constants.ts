export abstract class Constants {
  static readonly URL_API_GEOIP: string = 'http://127.0.0.1:5000/infoIP';
  static readonly URL_API_GEOIP_PROVIDER: string = 'ip-api';
}
