import XChainPage from './XChainPage';
import XAddressDetail from './Address/XAddressDetail';
// import { XTransactionDetails } from './XTransactionDetails';
import XPTransactions from './Transactions';

export { XChainPage, XAddressDetail, XPTransactions };
