export interface SearchMenuItem {
  type: string;
  link: string;
  label: string;
  avatar: string;
  avatarColor: string;
}
