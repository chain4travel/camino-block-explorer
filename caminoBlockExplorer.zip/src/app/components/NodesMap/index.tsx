import React, { Fragment } from "react";
import MapChart from "./MapChart";

const NodesMap = () => {
  return (
    <Fragment>
        <MapChart />
    </Fragment>
  );
}

export default NodesMap;