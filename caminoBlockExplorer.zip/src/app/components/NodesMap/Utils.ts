import axios from 'axios';
import LocationNode from "../../../types/locationNode";

class Utils {
    rpc : string;

    constructor(rpc : string) {

        this.rpc = rpc;
    }

    private async GetPeers(rpc : string) : Promise <any> {
        
        return new Promise((resolve, reject) => {
            var data = JSON.stringify({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "info.peers",
                "params": {
                    "nodeIDs": []
                }
            });

            var request = 
            {
                method: 'post',
                url: rpc + '/ext/info',
                headers: { 
                'Content-Type': 'application/json'
                },
                data : data
            };

            axios(request)
            .then(function (response) {
                resolve(response.data.result.peers);
            })
            .catch(function (error) {
                reject(error);
                console.log(error);
            });
        });
    }

    private async GetGeoIPInfo(ip : string) : Promise <any> {
        
        return new Promise((resolve, reject) => {
            var data = '';

            var request = 
            {
                method: 'get',
                url: `http://ip-api.com/json/${ip}`,
                headers: {},
                data : data
            };

            axios(request)
            .then(function (response) {
                resolve(response.data);
            })
            .catch(function (error) {
                reject(error);
                console.log(error);
            });
        });
    }

    private async getIpInfo(peers:any[],ipProvider: string)
    {
       let peersInfo = await this.GetPeers(this.rpc);
       let geoIPinfo : any[] = [];

       for (const peer of peers){

        geoIPinfo.push(this.GetGeoIPInfo(peer.ip.split(":")[0]));
       }
       return await Promise.all(geoIPinfo)

    }

    public async getPeersInfo(ipProvider: string)
    {
        let peersInfo = await this.GetPeers(this.rpc);
        let geoIPinfo : any = await this.getIpInfo(peersInfo,ipProvider);
        let geoIpPeersInfo : LocationNode[] = [];
        let info;

        for(let i = 0; i < peersInfo.length; i++)
        {
            info = {
                lng: geoIPinfo[i].lon,
                lat: geoIPinfo[i].lat,
                country: geoIPinfo[i].country,
                city: geoIPinfo[i].city,
                alpha2: geoIPinfo[i].countryCode,
                ip: geoIPinfo[i].query,
                nodeIdentity: peersInfo[i].nodeID
            }
            geoIpPeersInfo.push(info);
        }
        return geoIpPeersInfo;
        
    }
}

export default Utils;