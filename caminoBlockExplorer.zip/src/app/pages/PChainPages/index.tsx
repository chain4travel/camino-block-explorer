import PChainPage from './PChainPage';

export { PChainPage };
