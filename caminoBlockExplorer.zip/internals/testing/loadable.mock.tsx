import * as React from 'react';

export function ExportedFunc() {
  return <div>My lazy-loaded component</div>;
}
export default ExportedFunc;
