import * as path from 'path';

export const baseGeneratorPath = path.join(__dirname, '../../src/app');
